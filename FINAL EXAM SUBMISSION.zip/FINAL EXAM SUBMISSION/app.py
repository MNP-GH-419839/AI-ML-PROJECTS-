import streamlit as st
from transformers import DistilBertTokenizerFast, DistilBertForSequenceClassification
import torch
import numpy as np

# Load saved model and tokenizer
model_path = "saved_model"  # Replace with your actual path
model = DistilBertForSequenceClassification.from_pretrained(model_path)
tokenizer = DistilBertTokenizerFast.from_pretrained(model_path)
model.eval()

st.title("💊 Drug Review Sentiment Analysis")
st.markdown("Enter a drug review to predict if the sentiment is **positive** or **negative**.")

# User input
user_input = st.text_area("📝 Drug Review", height=150)

if st.button("Predict"):
    if user_input.strip() == "":
        st.warning("Please enter a review.")
    else:
        # Tokenize input
        inputs = tokenizer(user_input, return_tensors="pt", truncation=True, padding=True, max_length=256)
        
        # Model prediction
        with torch.no_grad():
            outputs = model(**inputs)
            logits = outputs.logits
            probs = torch.softmax(logits, dim=1).numpy()[0]
            pred_class = np.argmax(probs)
            confidence = probs[pred_class]

        sentiment = "😊 Positive" if pred_class == 1 else "😠 Negative"
        
        # Show result
        st.subheader("🧠 Prediction Result")
        st.write(f"**Sentiment:** {sentiment}")
        st.write(f"**Confidence Score:** {confidence:.2f}")
